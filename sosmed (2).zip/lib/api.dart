import 'dart:convert';
import 'package:http/http.dart' as http;

class Api {
  final String postUrl = "http://127.0.0.1:8000/api/post";

  final String userUrl = "http://127.0.0.1:8000/api/user";

  Future fetchDataPost() async {
    var result = await http.get(Uri.parse(postUrl));
    print(json.decode(result.body));
    return json.decode(result.body);
  }

  Future fetchDataUser() async {
    final result = await http.get(Uri.parse(userUrl));
    Map<String, dynamic> map = json.decode(result.body);

    return map;
  }

  Future kirimDataUser(String user, String password) async {
    return await http.post(Uri.parse("http://127.0.0.1:8000/api/user"),
        body: jsonEncode({'username': user, 'password': password}));
  }

  Future registerUser(String user, String password) async {
    final result = await http.post(Uri.parse("http://127.0.0.1:8000/api/user"),
        body: {'username': user, 'password': password});
    print(json.decode(result.body));
    return json.decode(result.body);
  }
}
