import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sosmed/login.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoadScreen(),
    );
  }
}

class LoadScreen extends StatefulWidget {
  const LoadScreen({Key? key}) : super(key: key);

  @override
  _LoadScreen createState() => _LoadScreen();
}

class _LoadScreen extends State<LoadScreen> {
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 2),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => LogScreen())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: new Center(
        child: new Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.home, size: 150, color: Colors.white),
              Text('Splash Screen',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
