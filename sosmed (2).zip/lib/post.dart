import 'package:flutter/material.dart';
import 'package:sosmed/api.dart';

Api api = Api();

void main() {
  runApp(MaterialApp(
    home: Post(),
  ));
}

class Post extends StatefulWidget {
  const Post({super.key});

  @override
  _Post createState() => _Post();
}

class _Post extends State<Post> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          leading: Icon(
            Icons.home,
            size: 37,
          ),
          title: Center(child: Text("Search User")),
          actions: <Widget>[
            Icon(
              Icons.account_circle,
              size: 40,
            )
          ],
        ),
        body: Container(
          color: Colors.white,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: null,
          tooltip: 'Post',
          child: Icon(Icons.add),
        ));
  }
}
