package com.example.sosmed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
