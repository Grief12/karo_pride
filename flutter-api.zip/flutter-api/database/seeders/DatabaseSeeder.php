<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\Akun;
use App\Models\PostModel;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // DB::table('post_models')->insert([
        //     'akuns_id' => 1,
        //     'akun_id' => 1,
        //     'message' => "tes relasi",
        //     'likes' => "5"

        // ]);
        // DB::table('post_models')->insert([
        //     'akuns_id' => 2,
        //     'akun_id' => 2,
        //     'message' => "relasi",
        //     'likes' => "5"
        // ]);

        DB::table('akuns')->insert([
            'username' => "bagas",
            'akun_id' => 1,
            'email' => "bagas@gmail.com",
            'password' => "123",
            'bio' => "halo saya bagas"
        ]);
        DB::table('akuns')->insert([
            'username' => "Pelindung anak-anak",
            'akun_id' => 2,
            'email' => "penaklukloli@gmail.com",
            'password' => "321",
            'bio' => "halo saya nata"
        ]);
		DB::table('akuns')->insert([
			'username' => "fardan",
			'akun_id' => 3,
			'email' => "fardan@gmail.com",
			'password' => "123",
			'bio' => "halo saya fardan"
		]);

        DB::table('chats')->insert([
            'akuns_id' => 2,
            'pengirim_id' => 1,
            'penerima_id' => 2,
            'message' => "halo nata",
        ]);
        DB::table('chats')->insert([
            'akuns_id' => 1,
            'pengirim_id' => 2,
            'penerima_id' => 1,
            'message' => "halo bagas",
        ]);
		DB::table('chats')->insert([
			'akuns_id' => 3,
            'pengirim_id' => 1,
            'penerima_id' => 3,
            'message' => "Free masson itu nyata di indo",
        ]);
        DB::table('chats')->insert([
			'akuns_id' => 3,
            'pengirim_id' => 2,
            'penerima_id' => 3,
            'message' => "halo fardan",
        ]);
        DB::table('chats')->insert([
			'akuns_id' => 3,
            'pengirim_id' => 2,
            'penerima_id' => 3,
            'message' => "oy dan",
        ]);
        DB::table('chats')->insert([
            'akuns_id' => 1,
            'pengirim_id' => 2,
            'penerima_id' => 1,
            'message' => "halo gasssss",
        ]);
        DB::table('chats')->insert([
            'akuns_id' => 1,
            'pengirim_id' => 2,
            'penerima_id' => 1,
            'message' => "uyy gasssss",
        ]);
        DB::table('users')->insert([
            'name' => Str::random(10),
            'email' => Str::random(10).'@gmail.com',
            'password' => Hash::make('password'),
        ]);
    }
}
