<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\PostModel;
use App\Models\Chat;
use App\Models\Akun;

class PostController extends Controller
{
    //

	var $data= [] ;
	
	public function post (){
		$post = PostModel::all();
		$relasi = DB::table('post_models')
		->join('akuns', 'post_models.akun_id','=','akuns.akun_id')
		->select('post_models.*', 'akuns.username')
		->get();

		$posts = PostModel::all();

		return response()->json(
		[
			'status' => 'terkoneksi',
			'data' => $relasi,
		]
		) ;
	}
	public function posting(Request $request) {
		$email = $request->username;
		$msg = $request->message;
		$like = $request->likes;
		$img = $request->imgurl;

		$user = Akun::firstWhere('email', $email);
		$akuns_id = $user->id;

		//$post = PostModel::create($request->all());
		if ($img == null) {

			$post = PostModel::create([
				'akuns_id' => $akuns_id,
			   'akun_id' => $akuns_id,
				'message' => $msg,
				'likes' => $like
			]);

			return response()->json([
				'status' => 'terkoneksi',
				'data' => $post,
			]);
		}
		else {

			$postt = PostModel::create([
				'akuns_id' => $akuns_id,
				'akun_id' => $akuns_id,
				'message' => $msg,
				'likes' => $like,
				'imgurl' => $img
			]);

			return response()->json([
			'status' => 'terkoneksi',
			'data' => $postt,
			]);
		}
	}
	
	//user
	public function user() {
		return response()->json([
			'status' => 'Terkoneksi',
			'data' => Akun::all(),
			'verif' => false,
			]);
	}
	public function verif (Request $req) {
		$akun = Akun::firstWhere('username', $req->username) ;

		return response()->json([
			'status' => 'Berhasil',
			'data' => $akun,
			'verif' => true,
		]);
	}

	public function profil($email){
		$id = Akun::firstWhere('email', $email);

		return response()->json(
			[
				'status' => 'Terkoneksi',
				'data' => $id,
			]
		);
	}
	public function update_profil ($email, Request $req){
		$id = Akun::firstWhere('email', $email) ;
		$profile = $req->profile ;
		$username = $req->username;
		$bio = $req->bio ;

		$akun = Akun::where('email', $email)->update([
			'profile' => $profile,
			'username' => $username,
			'bio' => $bio
		]);

		return response()->json(
			[
				'status' => 'Terkoneksi',
				'data' => $akun
			]
		);
	}

	// regis
	public function register(Request $request) {
		$akun = Akun::create($request->all());
		
		return  response()->json(
			[
				'status' => 'Terkoneksi',
				'data' => $akun,
			]
		);
	}
	// chat api
	public function chat($email) {
		//$chat = Chat::all();
		$akun = Akun::firstWhere('email', $email);
		$relasi = DB::table('chats')
		->where('pengirim_id', $akun->id)
		->join('akuns', 'chats.penerima_id','=','akuns.akun_id')
		->select('chats.*', 'akuns.username')
		->get();

		$user = DB::table('chats')
		->where('pengirim_id', $akun->id)
		->join('akuns', 'chats.penerima_id','=','akuns.akun_id')
		->select('akuns.username','chats.penerima_id','chats.pengirim_id')
		->groupBy('penerima_id')
		->get();

		//$akunss = Chat::distinct('username')->get();
		//$user = Chat::all()->groupBy('pengirim_id');
		//$tes = DB::table('chats')->where('pengirim_id', '2')->get();
		//$id = Akun::firstWhere('email', 'bagas@gmail.com');

		return response()->json([
			'status' => 'Terkoneksi',
			'akun' => $user,
			'data' => $relasi,
		]);
	}

	public function fetchChat(Request $req) {
		$email = $req->email ;
		$id = Akun::firstWhere('email', $email);
		//$chat = Chat::all() ;

		$fetch = Chat::firstWhere('pengirim_id', $id->id);

		return response()->json([
			'status' => 'Terkoneksi',
			'data' => $chat,
		]);
	}

}
