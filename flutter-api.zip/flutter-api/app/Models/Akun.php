<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Akun extends Model
{
    use HasFactory;

    protected $guarded = [
        'id',
        'akun_id',
    ];
    protected $cast = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    public function post_models(){
        return $this->hasMany(PostModel::class);
    }

    public function chats(){
        return $this->hasMany(Chats::class);
    }
    /**
     * Get the chats associated with the Akun
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
}
